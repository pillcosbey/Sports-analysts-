import os
from src.providers.odds_api_stub import get_nfl_odds

if not os.getenv("ODDS_API_KEY"):
    print("ODDS_API_KEY not found in environment. Add it to your .env file.")
    raise SystemExit(1)

data = get_nfl_odds()
print("Success. Sample size:", len(data))
if data and isinstance(data, list):
    sample = data[0]
    print("Sample sport key:", sample.get("sport_key"))
    print("Has bookmakers:", bool(sample.get("bookmakers")))
