#!/usr/bin/env bash
set -e
if [ ! -f .env ]; then
  echo ".env not found. Copying from .env.example (edit it to add your keys)."
  cp .env.example .env || true
fi
python -m pip install --upgrade pip
pip install -r requirements.txt
python src/pipeline.py --sport nfl --slate sunday --lookback 8 --min_conf 0.55
echo "Done. See ./out for CSVs."
