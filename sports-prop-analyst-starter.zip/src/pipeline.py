import os, argparse, pandas as pd, numpy as np
from dotenv import load_dotenv
from src.logic import PropSpec, evaluate_player_prop

# Provider stubs (swap to real APIs once keys added)
from src.providers.mock_loader import load_mock_week, load_mock_opponent_def

def main():
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument('--sport', default='nfl')
    parser.add_argument('--slate', default='sunday')
    parser.add_argument('--lookback', type=int, default=8)
    parser.add_argument('--min_conf', type=float, default=0.55)
    parser.add_argument('--out', default=os.getenv('OUTPUT_DIR', './out'))
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    # 1) Load data (replace with real provider adapters later)
    players_logs = load_mock_week()      # dict: player -> DataFrame
    opponent_defs = load_mock_opponent_def()  # dict: team -> Series

    # 2) Define prop menu you'd like to scan
    prop_menu = [
        PropSpec('rush_rec_yds', 100, '>='),
        PropSpec('rush_yds', 50, '>='),
        PropSpec('rec_yds', 60, '>='),
        PropSpec('receptions', 4, '>='),
        PropSpec('pass_tds', 2, '>=')
    ]


    rows = []
    for player, logs in players_logs.items():
        opp_team = logs.iloc[-1]['opp_team'] if len(logs) else 'UNK'
        opp_def = opponent_defs.get(opp_team, pd.Series(dtype=float))

        # Build prop menu; if market_lines has a threshold for this player+metric, use that instead.
        base_menu = [
            PropSpec('rush_rec_yds', 100, '>='),
            PropSpec('rush_yds', 50, '>='),
            PropSpec('rec_yds', 60, '>='),
            PropSpec('receptions', 4, '>='),
            PropSpec('pass_tds', 2, '>=')
        ]

        player_key = player.strip().lower()
        prop_menu = []
        for spec in base_menu:
            t = market_lines.get((player_key, spec.metric))
            if t is not None:
                prop_menu.append(PropSpec(spec.metric, float(t), '>='))
            else:
                prop_menu.append(spec)

        for spec in prop_menu:
            res = evaluate_player_prop(logs, opp_def, spec, args.lookback)
            row = {
                'player': player,
                'team': logs['team'].iloc[0] if len(logs) else '',
                'opponent': opp_team,
                'metric': spec.metric,
                'threshold': spec.threshold,
                **res
            }
            rows.append(row)

    df = pd.DataFrame(rows)
    df = df.sort_values('confidence', ascending=False)

    # 3) Filter & export
    top = df[df['confidence'] >= args.min_conf].copy()
    safe = top[top['confidence'] >= 0.65]
    medium = top[(top['confidence'] >= 0.58) & (top['confidence'] < 0.65)]
    risky = df[(df['confidence'] >= 0.5) & (df['confidence'] < args.min_conf)]

    out_safe = os.path.join(args.out, 'props_safe.csv')
    out_medium = os.path.join(args.out, 'props_medium.csv')
    out_risky = os.path.join(args.out, 'props_risky.csv')
    out_all = os.path.join(args.out, 'props_all.csv')

    df.to_csv(out_all, index=False)
    safe.to_csv(out_safe, index=False)
    medium.to_csv(out_medium, index=False)
    risky.to_csv(out_risky, index=False)

    print(f"Exported:\n- {out_all}\n- {out_safe}\n- {out_medium}\n- {out_risky}")

if __name__ == '__main__':
    main()
