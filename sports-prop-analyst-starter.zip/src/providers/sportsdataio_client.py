# Real SportsDataIO adapter (templated) — requires a valid key.
# Docs: https://sportsdata.io/developers (choose NFL and check "stats" + "scores" APIs)
import os, requests, pandas as pd, datetime as dt

NFL_BASE = "https://api.sportsdata.io/v3/nfl"

def _key() -> str:
    key = os.getenv("SPORTSDATAIO_KEY")
    if not key:
        raise RuntimeError("Set SPORTSDATAIO_KEY in .env")
    return key

def _headers():
    return {"Ocp-Apim-Subscription-Key": _key()}

def get_current_season() -> int:
    # Season endpoint can vary; many seasons are by year (e.g., 2025).
    # This fallback assumes current year; adjust if your plan includes a season endpoint.
    return dt.datetime.now().year

def get_player_game_logs(season: int, player_id: str) -> pd.DataFrame:
    """Return game logs as a DataFrame with columns used by our logic:
    date, team, opp_team, rush_yds, rec_yds, receptions, rush_rec_yds, pass_tds.
    """
    url = f"{NFL_BASE}/stats/json/PlayerGameStatsByPlayerID/{season}/{player_id}"
    r = requests.get(url, headers=_headers(), timeout=30)
    r.raise_for_status()
    data = r.json()
    if not isinstance(data, list):
        data = [data]

    rows = []
    for g in data:
        date = g.get("Date") or g.get("GameDate")
        try:
            date = pd.to_datetime(date)
        except Exception:
            date = pd.NaT
        team = g.get("Team")
        opp = g.get("Opponent") or g.get("OpponentAbbr") or g.get("OpponentID")
        rush = g.get("RushingYards", 0) or 0
        rec_yards = g.get("ReceivingYards", 0) or 0
        recs = g.get("Receptions", 0) or 0
        pass_tds = g.get("PassingTouchdowns", 0) or 0
        rows.append({
            "date": date,
            "team": team,
            "opp_team": opp,
            "rush_yds": rush,
            "rec_yds": rec_yards,
            "receptions": recs,
            "rush_rec_yds": (rush or 0) + (rec_yards or 0),
            "pass_tds": pass_tds
        })
    df = pd.DataFrame(rows)
    return df

def get_team_defense_percentiles(season: int) -> dict:
    """Build opponent 'ease' percentiles by team for metrics we score.
    Uses TeamSeasonStats or similar endpoint; you may need to adjust field names per your plan.
    """
    url = f"{NFL_BASE}/stats/json/TeamSeasonStats/{season}"
    r = requests.get(url, headers=_headers(), timeout=30)
    r.raise_for_status()
    stats = r.json()

    df = pd.DataFrame(stats)

    def safe(col):
        return df[col] if col in df.columns else 0

    rush_allowed = safe("OpponentRushingYards") or safe("RushingYardsAllowed")
    rec_allowed = safe("OpponentReceivingYards") or safe("ReceivingYardsAllowed")
    recs_allowed = safe("OpponentReceptions") or safe("ReceptionsAllowed")
    pass_tds_allowed = safe("OpponentPassingTouchdowns") or safe("PassingTouchdownsAllowed")

    def pct(series):
        s = pd.to_numeric(series, errors="coerce").fillna(0)
        return s.rank(pct=True).astype(float)

    pct_rush = pct(rush_allowed)
    pct_rec = pct(rec_allowed)
    pct_recs = pct(recs_allowed)
    pct_pass_tds = pct(pass_tds_allowed)

    out = {}
    df_reset = df.reset_index(drop=True)
    for idx in range(len(df_reset)):
        row = df_reset.iloc[idx]
        team = row.get("Team") or row.get("TeamAbbreviation") or row.get("TeamKey")
        out[team] = pd.Series({
            "rush_yds_allowed_pct": float(pct_rush.iloc[idx]),
            "rec_yds_allowed_pct": float(pct_rec.iloc[idx]),
            "receptions_allowed_pct": float(pct_recs.iloc[idx]),
            "rush_rec_yds_allowed_pct": float((pct_rush.iloc[idx] + pct_rec.iloc[idx]) / 2.0),
            "pass_tds_allowed_pct": float(pct_pass_tds.iloc[idx])
        })
    return out
