# The Odds API stub — replace with real calls once you add your key.
# Docs: https://the-odds-api.com/
import os, requests

BASE = "https://api.the-odds-api.com/v4"

def get_nfl_odds():
    key = os.getenv('ODDS_API_KEY')
    if not key:
        raise RuntimeError('Set ODDS_API_KEY in .env')
    # Example: get NFL game odds (not props)
    params = {
        'apiKey': key,
        'regions': 'us',
        'markets': 'h2h,totals',
        'oddsFormat': 'american'
    }
    url = f"{BASE}/sports/americanfootball_nfl/odds"
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    return r.json()
