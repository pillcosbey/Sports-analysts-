# The Odds API client — pulls odds and (if plan supports) player props.
# Docs: https://the-odds-api.com/
import os, requests

BASE = "https://api.the-odds-api.com/v4"

def _key():
    key = os.getenv("ODDS_API_KEY")
    if not key:
        raise RuntimeError("Set ODDS_API_KEY in .env")
    return key

def get_odds(sport_key="americanfootball_nfl", regions="us", markets="h2h,totals", odds_format="american"):
    url = f"{BASE}/sports/{sport_key}/odds"
    params = {
        "apiKey": _key(),
        "regions": regions,
        "markets": markets,
        "oddsFormat": odds_format,
    }
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

def get_events(sport_key="americanfootball_nfl"):
    url = f"{BASE}/sports/{sport_key}/events"
    params = {"apiKey": _key()}
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

def get_player_props(sport_key="americanfootball_nfl", regions="us", markets=None):
    """Fetch player props if your plan provides it.
    'markets' should be a comma-separated list supported by your account, e.g.:
      player_pass_tds,player_pass_yds,player_receptions,player_rush_yds,player_rec_yds,player_rush_rec_yds
    If your plan doesn't include player props, this will likely return 403/404.
    """
    if markets is None:
        # Default guess of common player prop markets. Adjust based on your plan.
        markets = "player_receptions,player_rec_yds,player_rush_yds,player_rush_rec_yds,player_pass_tds"
    url = f"{BASE}/sports/{sport_key}/odds"
    params = {
        "apiKey": _key(),
        "regions": regions,
        "markets": markets,
        "oddsFormat": "american",
    }
    r = requests.get(url, params=params, timeout=30)
    r.raise_for_status()
    return r.json()
