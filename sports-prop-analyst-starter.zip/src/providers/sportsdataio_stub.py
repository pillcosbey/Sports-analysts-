# SportsDataIO stub — replace with real calls once you add your key.
# Docs: https://sportsdata.io/developers
import os, requests

BASE = "https://api.sportsdata.io/v3/nfl"

def get_player_game_logs(season: int, player_id: int):
    key = os.getenv('SPORTSDATAIO_KEY')
    if not key:
        raise RuntimeError('Set SPORTSDATAIO_KEY in .env')
    url = f"{BASE}/stats/json/PlayerGameStatsByPlayerID/{season}/{player_id}"
    headers = {'Ocp-Apim-Subscription-Key': key}
    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()
    return r.json()
