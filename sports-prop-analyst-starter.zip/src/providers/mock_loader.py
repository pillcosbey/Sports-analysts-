import pandas as pd
from datetime import datetime, timedelta
import numpy as np

# Simple mock players with last 10 games
def _player_log(name, team, opp_seq, rush, rec, recs, pass_tds):
    dates = [datetime(2025, 9, 1) - timedelta(days=7*i) for i in range(len(opp_seq))]
    df = pd.DataFrame({
        'date': dates,
        'team': team,
        'opp_team': opp_seq,
        'rush_yds': rush,
        'rec_yds': rec,
        'receptions': recs,
        'rush_rec_yds': [r+rc for r, rc in zip(rush, rec)],
        'pass_tds': pass_tds
    })
    df['player'] = name
    return df

def load_mock_week():
    # Example players
    mccaffrey = _player_log(
        'Christian McCaffrey', 'SF',
        ['ARI','LAR','SEA','DAL','ARI','SEA','LAR','ARI','SEA','DAL'],
        rush=[112, 88, 104, 129, 97, 115, 101, 83, 140, 95],
        rec=[28, 45, 33, 21, 44, 37, 62, 30, 24, 55],
        recs=[3, 5, 4, 3, 4, 4, 6, 3, 2, 5],
        pass_tds=[0,0,0,0,0,0,0,0,0,0]
    )
    waddle = _player_log(
        'Jaylen Waddle', 'MIA',
        ['BUF','NYJ','NE','BUF','NYJ','NE','TEN','BUF','NYJ','NE'],
        rush=[0, 4, 0, 0, 0, 0, 0, 0, 0, 0],
        rec=[72, 61, 84, 103, 66, 49, 90, 58, 70, 64],
        recs=[4, 5, 7, 6, 5, 4, 6, 5, 5, 6],
        pass_tds=[0]*10
    )
    burrow = _player_log(
        'Joe Burrow', 'CIN',
        ['PIT','CLE','BAL','PIT','CLE','BAL','PIT','CLE','BAL','PIT'],
        rush=[8, 2, 5, 3, 4, 7, 6, 3, 5, 2],
        rec=[0]*10,
        recs=[0]*10,
        pass_tds=[2,3,1,2,2,3,0,2,1,3]
    )
    return {
        'Christian McCaffrey': mccaffrey,
        'Jaylen Waddle': waddle,
        'Joe Burrow': burrow
    }

def load_mock_opponent_def():
    # Percentile where 1 = very easy defense for that metric
    # For simplicity, use same percentiles for all metrics except pass_tds
    teams = ['ARI','BUF','PIT','CLE','BAL','NE','NYJ','SEA','DAL','LAR','TEN']
    data = {}
    for t in teams:
        data[t] = pd.Series({
            'rush_yds_allowed_pct': np.random.uniform(0.2, 0.9),
            'rec_yds_allowed_pct': np.random.uniform(0.2, 0.9),
            'rush_rec_yds_allowed_pct': np.random.uniform(0.2, 0.9),
            'receptions_allowed_pct': np.random.uniform(0.2, 0.9),
            'pass_tds_allowed_pct': np.random.uniform(0.2, 0.9)
        })
    return data
