from dataclasses import dataclass
import pandas as pd
import numpy as np

@dataclass
class PropSpec:
    metric: str          # e.g., 'rush_yds', 'rec_yds', 'rush_rec_yds', 'receptions', 'pass_tds'
    threshold: float     # e.g., 50.0
    qualifier: str = ''  # e.g., '>=', '>'

def calc_hit_rate(game_logs: pd.DataFrame, spec: PropSpec, lookback: int = 8) -> float:
    """Compute hit rate over last N games for a given prop spec.
    game_logs columns should include the metric in spec.metric.
    """
    df = game_logs.sort_values('date', ascending=False).head(lookback).copy()
    if df.empty or spec.metric not in df.columns:
        return np.nan
    if spec.qualifier in ('>=', '=>', ''):
        hits = (df[spec.metric] >= spec.threshold).sum()
    elif spec.qualifier == '>':
        hits = (df[spec.metric] > spec.threshold).sum()
    elif spec.qualifier == '<=':
        hits = (df[spec.metric] <= spec.threshold).sum()
    elif spec.qualifier == '<':
        hits = (df[spec.metric] < spec.threshold).sum()
    else:
        hits = (df[spec.metric] >= spec.threshold).sum()
    total = len(df)
    return float(hits) / float(total) if total else np.nan

def opponent_adjustment(opponent_def_stats: pd.Series, metric: str) -> float:
    """Return an adjustment factor based on opponent defensive percentile.
    Expect opponent_def_stats to include percentiles like 'rush_yds_allowed_pct' (1 = easy).
    """
    key = f"{metric}_allowed_pct"
    if key not in opponent_def_stats.index or pd.isna(opponent_def_stats[key]):
        return 1.0
    pct = opponent_def_stats[key]  # 0..1 (1 = allows a lot = easier)
    # Map percentile to a modest multiplier 0.9..1.1
    return 0.9 + 0.2 * pct

def confidence_score(hit_rate: float, adj: float, sample: int) -> float:
    """Combine factors into a single confidence score 0..1.
    - hit_rate: empirical last-N hit rate
    - adj: opponent ease multiplier
    - sample: games counted (stabilizer)
    """
    if np.isnan(hit_rate) or hit_rate <= 0 or sample <= 0:
        return 0.0
    # Beta prior to stabilize small samples
    prior_mean = 0.55
    prior_weight = 4
    post = (hit_rate * sample + prior_mean * prior_weight) / (sample + prior_weight)
    score = np.clip(post * adj, 0, 1)
    return float(score)

def evaluate_player_prop(player_logs: pd.DataFrame,
                         opp_def: pd.Series,
                         spec: PropSpec,
                         lookback: int = 8) -> dict:
    hr = calc_hit_rate(player_logs, spec, lookback)
    adj = opponent_adjustment(opp_def, spec.metric)
    sample = min(lookback, len(player_logs))
    conf = confidence_score(hr, adj, sample)
    return {
        'hit_rate': round(hr, 3) if not np.isnan(hr) else None,
        'opp_adj': round(adj, 3),
        'sample': sample,
        'confidence': round(conf, 3)
    }
