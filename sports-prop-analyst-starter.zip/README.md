# Sports Prop Analyst — Starter Kit

This starter shows how to build an Outlier-style props analyzer with Python.

## What it does
1) Pulls (or loads) player game logs and opponent defensive stats.
2) Computes *hit rates* for props (e.g., 50+ rush yards).
3) Adjusts hit rates by opponent strength.
4) Ranks props by a composite **confidence score**.
5) Exports results to CSV; optional Google Sheets.

> Note: API calls are templated — add your API keys in `.env` and uncomment calls.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env  # add your keys
python src/pipeline.py --sport nfl --slate sunday --lookback 8 --min_conf 0.55
```

## Files
- `src/pipeline.py` — orchestrates load → compute → rank → export
- `src/logic.py` — hit-rate and confidence scoring
- `src/providers/*` — API adapters (SportsDataIO, The Odds API stubs)
- `data/mock_*` — sample mock data to test without APIs
- `notebooks/prop_analysis_demo.ipynb` — playground

## Supported providers (add your keys)
- SportsDataIO (stats, game logs)
- The Odds API (odds & props)
- Stathead/Pro-Football-Reference (manual downloads)
- CSV uploads from Outlier or your own exports

## Safety & Terms
Use official APIs and respect terms of service. Avoid scraping sites that prohibit it.


---

## One‑tap setup on iPhone via **GitHub Codespaces**
1. Create a GitHub repo and upload this folder (or just upload the ZIP and extract in the repo).
2. In the repo, tap **Code** → **Codespaces** → **Create codespace on main**.
3. In the Codespaces terminal:
   ```bash
   echo "ODDS_API_KEY=YOUR_KEY" >> .env
   # optional:
   # echo "SPORTSDATAIO_KEY=YOUR_KEY" >> .env
   bash scripts/run_props.sh
   ```
4. CSVs will appear in `/workspaces/<repo>/out` (download via VS Code file explorer).

## Automated daily run with **GitHub Actions**
- Add repository **Secrets**: `ODDS_API_KEY` (required), `SPORTSDATAIO_KEY` (optional).
- The workflow at `.github/workflows/pipeline.yml` runs daily at 13:00 UTC and on manual trigger.
- Outputs are saved as an **Artifact** named `props-output` under the workflow run.
